public class If {
	public static void main(String[] args) {

		if (2>1) {

			System.out.println("Access granted.");

		}

	}
}
