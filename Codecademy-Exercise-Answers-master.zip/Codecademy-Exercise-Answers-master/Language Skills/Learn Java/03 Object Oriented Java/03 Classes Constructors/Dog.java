class Dog {
	public Dog(){

  }

	public static void main(String[] args) {

	}
}
