public class DataTypesB {
	public static void main(String[] args) {

		System.out.println(true);

	}
}
