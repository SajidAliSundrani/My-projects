public class Arithmetic {
	public static void main(String[] args) {

		int myNumber = 23 * 12;
		System.out.println(myNumber);

	}
}
