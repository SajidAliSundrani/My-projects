public class DataTypesC {
	public static void main(String[] args) {

		System.out.println('f');

	}
}
