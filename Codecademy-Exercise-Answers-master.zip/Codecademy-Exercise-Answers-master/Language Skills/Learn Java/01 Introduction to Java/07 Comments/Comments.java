public class Comments {
	public static void main(String[] args) {

		// System.out.println("Noise!");
		/*

    anything
		*/

	}
}
