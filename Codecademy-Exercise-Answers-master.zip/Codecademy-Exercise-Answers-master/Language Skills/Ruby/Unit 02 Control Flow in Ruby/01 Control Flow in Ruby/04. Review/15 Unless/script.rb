unless false
puts "hello"
end