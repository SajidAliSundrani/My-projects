if gets.chomp <3
	print "hello"
else print "bye"
end