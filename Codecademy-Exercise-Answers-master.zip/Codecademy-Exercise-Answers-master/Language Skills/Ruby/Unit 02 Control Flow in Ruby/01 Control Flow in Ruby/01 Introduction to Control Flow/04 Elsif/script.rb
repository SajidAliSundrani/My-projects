if 44 <3
	print "hello"
elsif 344<222 
	print "bye"
else 
	puts "wahaha!"
end