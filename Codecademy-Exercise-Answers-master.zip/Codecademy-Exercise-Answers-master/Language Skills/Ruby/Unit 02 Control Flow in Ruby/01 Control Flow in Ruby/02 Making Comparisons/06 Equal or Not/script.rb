is_true = 2 != 3

is_false = 2 == 3