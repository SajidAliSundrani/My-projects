print "Get me some text"
user_input = gets.chomp