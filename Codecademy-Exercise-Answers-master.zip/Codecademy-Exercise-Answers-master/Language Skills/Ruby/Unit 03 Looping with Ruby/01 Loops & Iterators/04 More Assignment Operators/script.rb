counter = 1
while counter < 11
  puts counter
  counter += 1
end