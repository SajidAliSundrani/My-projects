i = 0
while i < 5
  puts i
  i = i + 5
end