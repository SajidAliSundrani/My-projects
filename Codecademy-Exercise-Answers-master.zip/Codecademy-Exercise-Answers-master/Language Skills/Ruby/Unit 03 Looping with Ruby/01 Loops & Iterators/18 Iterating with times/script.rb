30.times{ print "Ruby!" }
