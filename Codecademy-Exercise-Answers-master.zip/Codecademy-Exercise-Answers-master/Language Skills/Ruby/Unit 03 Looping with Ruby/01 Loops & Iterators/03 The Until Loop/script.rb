counter = 1
until counter > 10
  puts counter
  counter = counter + 1
end