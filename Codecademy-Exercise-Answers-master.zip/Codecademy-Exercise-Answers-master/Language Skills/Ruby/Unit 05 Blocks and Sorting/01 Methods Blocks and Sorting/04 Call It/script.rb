def array_of_10
  puts (1..10).to_a
end

array_of_10()
