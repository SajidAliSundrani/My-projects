puts "input: "
text = gets.chomp
words = text.split

frequencies = Hash.new(0)
