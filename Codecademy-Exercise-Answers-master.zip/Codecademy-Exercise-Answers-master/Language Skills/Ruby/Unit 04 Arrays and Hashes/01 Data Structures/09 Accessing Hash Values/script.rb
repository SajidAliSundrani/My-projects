pets = Hash.new
pets["Bob"]="dog"
puts pets["Bob"]
