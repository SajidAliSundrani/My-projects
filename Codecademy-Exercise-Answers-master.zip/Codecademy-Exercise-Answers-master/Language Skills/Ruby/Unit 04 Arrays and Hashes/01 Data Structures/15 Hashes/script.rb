my_hash = {
    "one" => 1,
    "two" => 2
    }
