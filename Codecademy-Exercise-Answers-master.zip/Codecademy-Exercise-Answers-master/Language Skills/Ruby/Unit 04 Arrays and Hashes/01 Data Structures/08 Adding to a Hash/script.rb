pets = Hash.new
pets["Bob"]="dog"
