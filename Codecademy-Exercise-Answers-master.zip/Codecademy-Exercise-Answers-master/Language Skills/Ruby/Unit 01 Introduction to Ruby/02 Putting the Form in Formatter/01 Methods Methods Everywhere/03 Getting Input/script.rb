print "What's your first name?"
first_name = gets.chomp
first_name.capitalize!
