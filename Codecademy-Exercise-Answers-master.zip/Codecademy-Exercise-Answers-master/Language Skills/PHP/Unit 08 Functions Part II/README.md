##1.)
```php
<html>
    <head>
		<title></title>
	</head>
	<body>
      <p>
        <?php
          echo(strlen("dsfa345w34gdasfhgdw5yweshse5s3egsadfrtw34tawgefW3Q4TQW2AGAQ346TQ23AWGWA34TYQ345TG123IUHTI3T2597690R8UQT34UTR    2O83RGIQYF4IQ7WY4TIQYTG9A78TGEF9IUAWFI37YAQTF2utgrv2iqufgri7yawgfviwq7yfriy4rf7wufg7iw374tfg9o4q3"));
        ?>
      </p>
    </body>
</html>
```
##2.)
No changes needed.
##3.)
```php
<html>
	<head>
		<title></title>
	</head>
	<body>
      <p>
        <?php
        // Write your function below!
        function displayname(){
            
            echo "not a";
            }
        
        
        
        ?>
      </p>
    </body>
</html>
```
##4.)
```php
<html>
	<head>
		<title></title>
	</head>
	<body>
      <p>
        <?php
        // Write your function below!
        function displayname(){
            
            echo "not a";
        }
        
        
        displayname();;
        
        ?>
      </p>
    </body>
</html>
```
##5.)
```php
<html>
	<head>
		<title></title>
	</head>
	<body>
      <?php
        function returnname(){
            return "dsafd";
            }
      ?>
    </body>
</html>
```
##6.)
```php<html>
	<head>
		<title></title>
	</head>
	<body>
      <p>
        <?php
        function greetings($name) {
            echo ("Greetings, " . $name . "!");
        }

        $name = "Todd";
        greetings($name);
    ?>
      </p>
    </body>
</html>
```
##7.)
```php
<html>
	<head>
		<title></title>
	</head>
	<body>
      <p>
        <?php
        function aboutme($name, $age){
            echo "Hello! My name is ", $name," and I am ", $age ," years old.";
        }
        aboutme("brice","3");
      
        ?>
      </p>
    </body>
</html>
```