# Set maximum to the max value of any set of numbers on line 3!

maximum = max(3,5,10,2)

print maximum
