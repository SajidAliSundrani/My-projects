import math

print math.sqrt(13689)
