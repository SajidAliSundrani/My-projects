n = [1, 3, 5]

# Add your code below
print n[1]
