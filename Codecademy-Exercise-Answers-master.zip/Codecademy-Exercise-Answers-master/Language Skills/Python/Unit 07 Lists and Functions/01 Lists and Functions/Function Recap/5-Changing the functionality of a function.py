number = 5

def my_function(x):
    return x * 3

print my_function(number)
