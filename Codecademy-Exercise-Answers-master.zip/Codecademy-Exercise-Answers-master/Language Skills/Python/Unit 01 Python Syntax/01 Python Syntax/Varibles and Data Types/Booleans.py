# Set the variables to the values listed in the instructions!

my_int = 7
my_float = 1.23
my_bool = True

print (my_int)
print (my_float)
print (my_bool)
