#Set eggs equal to 100 using exponentiation on line 3!

eggs = 10 ** 2

print eggs
