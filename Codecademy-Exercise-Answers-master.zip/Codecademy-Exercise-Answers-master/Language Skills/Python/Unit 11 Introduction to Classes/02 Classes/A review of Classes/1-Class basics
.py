class Car(object):
    pass
