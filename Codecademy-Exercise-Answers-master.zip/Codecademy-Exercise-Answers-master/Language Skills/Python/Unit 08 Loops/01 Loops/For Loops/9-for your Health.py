print "Counting..."

for i in range(20):
    print i

    
