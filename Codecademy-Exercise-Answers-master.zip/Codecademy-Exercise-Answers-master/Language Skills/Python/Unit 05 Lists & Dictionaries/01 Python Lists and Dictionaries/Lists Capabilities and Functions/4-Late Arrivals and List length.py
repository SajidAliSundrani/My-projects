suitcase = []
suitcase.append("sunglasses")

# Your code here!
suitcase.append('treta')
suitcase.append('azul')
suitcase.append('cell')

list_length = len(suitcase) # Set this to the length of suitcase

print "There are %d items in the suitcase." % (list_length)
print suitcase
