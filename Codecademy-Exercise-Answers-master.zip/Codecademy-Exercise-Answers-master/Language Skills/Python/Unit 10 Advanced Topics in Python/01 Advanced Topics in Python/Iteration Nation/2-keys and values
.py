my_dict = {
    "name": "Arthur",
    "age": 24,
    "color":"blue",
    "game":"PoE"
}
print my_dict.keys()
print my_dict.values()
