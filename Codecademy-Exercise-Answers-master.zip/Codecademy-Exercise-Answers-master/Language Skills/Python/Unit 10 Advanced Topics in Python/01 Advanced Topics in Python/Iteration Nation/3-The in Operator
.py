my_dict = { "name": "Arthur", "age": 24, "color":"blue", "game":"PoE"}
print my_dict.keys()
print my_dict.values()

for key in my_dict:
    print key, my_dict[key]
