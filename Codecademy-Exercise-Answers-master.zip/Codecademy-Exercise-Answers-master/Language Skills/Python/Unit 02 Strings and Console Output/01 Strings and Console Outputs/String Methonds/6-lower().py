parrot = "Norwegian Blue"

print parrot.lower()
