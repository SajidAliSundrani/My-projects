# Turn 3.14 into a string on line 3!

print "The value of pi is around " + str(3.14)
