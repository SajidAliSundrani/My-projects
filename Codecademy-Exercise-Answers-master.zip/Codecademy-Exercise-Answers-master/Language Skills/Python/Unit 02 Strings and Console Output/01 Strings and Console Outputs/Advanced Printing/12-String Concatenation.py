# Print the concatenation of "Spam and eggs" on line 3!

print "Spam " + "and " + "eggs"
