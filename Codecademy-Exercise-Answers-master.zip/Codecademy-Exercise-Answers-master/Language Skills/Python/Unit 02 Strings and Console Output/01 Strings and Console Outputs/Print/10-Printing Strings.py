"""Tell Python to print "Monty Python"
to the console on line 4!"""

print "Monty Python"
