# Make sure that the_flying_circus() returns True
def the_flying_circus():
    if 10 < 11 or 5<(6+1):    # Start coding here!
        return True # Don't forget to indent
        # the code inside this block!
    elif 7 >= 2:
        return False # Keep going here.
        # You'll want to add the else statement, too!
    else:
        return True

print the_flying_circus()
