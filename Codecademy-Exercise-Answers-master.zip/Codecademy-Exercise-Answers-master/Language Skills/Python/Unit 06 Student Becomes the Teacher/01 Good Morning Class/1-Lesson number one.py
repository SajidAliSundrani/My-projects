lloyd = {
    'name':'Lloyd',
    'homework':[],
    'quizzes':[],
    'tests':[]
    }

alice = {
    'name':'Alice',
    'homework':[],
    'quizzes':[],
    'tests':[]
    }

tyler = {
    'name':'Tyler',
    'homework':[],
    'quizzes':[],
    'tests':[]
    }
